RTIMU: https://github.com/RTIMULib/RTIMULib2 (+ `sudo apt-get install python-dev`)
RPi.GPIO: `sudo pip install RPi.GPIO`
gpsd: `sudo apt-get install gpsd gpsd-clients python-gps` (+ https://learn.adafruit.com/adafruit-ultimate-gps-on-the-raspberry-pi/setting-everything-up)
RFM69: https://github.com/etrombly/RFM69
py-spidev: https://github.com/Gadgetoid/py-spidev